package com.musk.springboot.firstdemo.jpa.repository;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.musk.springboot.firstdemo.model.Book;


@Repository
@Transactional
public class BookRepository {
	
	
	@Autowired
	EntityManager em;

	public void insert(Book b) {
		
		System.out.println("Inside Book Repository insert method.."+b);
	    em.persist(b);
		
	}

}