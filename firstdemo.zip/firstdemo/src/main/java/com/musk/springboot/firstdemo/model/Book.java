package com.musk.springboot.firstdemo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Component
@Table(name="Book")
public class Book {
	
	@Id
	@GeneratedValue
	private int bookid;
	
	
	private String bookname;
	private String bookauthor;

	
	
	public Book()
	{
		System.out.println("Book bean created..");
	}
	
	
	public Book(int bookid, String bookname,String bookauthor) {
		super();
		this.bookid = bookid;
		this.bookname = bookname;
		this.bookauthor = bookauthor;
		
	}
	

	public int getBookid() {
		return bookid;
	}

	public String getBookname() {
		return bookname;
	}


	public void setBookname(String bookname) {
		this.bookname = bookname;
	}


	public String getBookauthor() {
		return bookauthor;
	}


	public void setBookauthor(String bookauthor) {
		this.bookauthor = bookauthor;
	}


	@Override
	public String toString() {
		return "Book [bookId=" + bookid + ", bookName=" + bookname + ", authorName=" + bookauthor + "]";
	}


	@Override
	public boolean equals(Object obj) {
		return  this.bookid == ((Book)obj).bookid;
	}
	
	
	

}

